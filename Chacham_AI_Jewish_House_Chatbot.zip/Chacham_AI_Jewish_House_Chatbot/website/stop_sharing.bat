@echo off
title Stop sharing Chacham AI
"C:\Program Files\Tailscale\tailscale.exe" funnel reset
echo.
echo  Sharing is now OFF. The public link no longer works.
echo.
pause
