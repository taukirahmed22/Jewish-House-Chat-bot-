@echo off
title Share Chacham AI with my teacher
set TS="C:\Program Files\Tailscale\tailscale.exe"
if not exist %TS% (
  echo  Tailscale is not installed in the usual place. Install it from tailscale.com/download
  pause
  exit /b
)
echo.
echo  Step 1/3: sharing the chat page...
%TS% funnel --bg --https=10000 http://localhost:10000
echo.
echo  Step 2/3: sharing ONLY the chatbot address (the n8n editor stays private)...
%TS% funnel --bg --https=10000 --set-path /webhook http://localhost:5678/webhook
echo.
echo  Step 3/3: your public link:
echo  ------------------------------------------------------------
%TS% funnel status
echo  ------------------------------------------------------------
echo.
echo  If you see a link about enabling Funnel above, open it, click Enable,
echo  then double-click this file again.
echo.
echo  Send your teacher the https://....ts.net:10000 link shown above.
echo  Keep your laptop on, with Docker, Ollama, n8n and start_website.bat running.
echo.
pause
