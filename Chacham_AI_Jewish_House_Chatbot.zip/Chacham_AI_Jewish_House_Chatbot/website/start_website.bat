@echo off
cd /d "%~dp0"
set PY=python
where python >nul 2>nul || set PY=py
echo.
echo  Starting the Chacham AI website on http://localhost:10000 ...
echo  Keep this window open during your demo. Close it to stop the website.
echo.
start "" cmd /c "timeout /t 3 >nul & start http://localhost:10000/"
%PY% -m http.server 10000
echo.
echo  The website stopped or could not start. Read the message above.
pause
