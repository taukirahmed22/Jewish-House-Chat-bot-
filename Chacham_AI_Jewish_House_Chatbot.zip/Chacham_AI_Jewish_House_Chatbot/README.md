# Chacham AI — Jewish House Support Assistant

A safe, grounded RAG chatbot for **Jewish House, Bondi** (24/7 crisis and welfare support).
It answers common questions only from Jewish House's approved content, and shows the
24/7 Crisis Line **1300 544 357** instantly when a message shows signs of crisis.

ITSU3018 Professional Project 1 · Group 2026S2_23 · Victorian Institute of Technology, Sydney
Supervisor: Dr Shakil Ahmed · Client: Jewish House

## How it works

```
Visitor ─► Chat Trigger ─► Crisis Filter (regex rules) ─► Is Crisis?
                                                    ├─ yes ─► Crisis Card (fixed reply, no AI)
                                                    └─ no  ─► AI Agent ─► Qdrant top 4 (Ollama embeddings)
                                                                       └► Gemini 3.5 Flash-Lite writes the reply
```

- **Crisis filter first.** About 25 deterministic patterns (suicide, self-harm, "not safe", abuse,
  "nowhere to sleep tonight"…) run before any AI step.
- **Strict scope.** The agent may only answer from what the knowledge base returns; anything else is
  politely refused, and missing answers are handed to the Jewish House team on (02) 9386 0770.
- **Local retrieval.** Embeddings (nomic-embed-text, 768 dimensions) and vector search (Qdrant) run on
  the host machine; only the final wording uses the cloud model.

## Stack

| Part | Tool | Port |
|---|---|---|
| Workflow (9 nodes) | n8n in Docker | 5678 |
| Vector database | Qdrant in Docker, collection `jh_qa` | 6333 |
| Embeddings | Ollama + `nomic-embed-text` | 11434 |
| Answer wording | Google Gemini `gemini-3.5-flash-lite` | — |
| Chat website | HTML / CSS / JavaScript | 10000 |
| Public HTTPS link | Tailscale Funnel | — |

## Folder layout

```
n8n/
  docker-compose.yml                n8n + Qdrant, bound to 127.0.0.1
  JH_RAG_Assistant.workflow.json    the full workflow (import into n8n)
knowledge_base/
  knowledge_base.csv                828 entries: 789 PDF chunks + 39 approved Q&A
  build_chunks.py                   turns the Jewish House PDFs into labelled chunks
  load_kb.py                        embeds the CSV with Ollama and loads Qdrant
website/
  index.html                        chat page (with the Chacham AI avatar)
  start_website.bat                 serves the page on http://localhost:10000
  share_with_teacher.bat            opens a public HTTPS link with Tailscale Funnel
  stop_sharing.bat                  closes the public link
docs/
  Chacham_AI_Source_Code.pdf        all source code, printed and organised
```

## Run it

1. Install **Docker Desktop**, **Ollama** and **Python 3**, then run `ollama pull nomic-embed-text`.
2. Start n8n and Qdrant:
   ```
   cd n8n
   docker compose up -d
   ```
3. Open http://localhost:5678, create the owner account, then **Import from file** →
   `JH_RAG_Assistant.workflow.json`.
4. Add three credentials in n8n:
   - Qdrant: URL `http://host.docker.internal:6333`
   - Ollama: URL `http://host.docker.internal:11434`
   - Google Gemini (PaLM) API: your own key from Google AI Studio
5. Load the knowledge base (about 30 minutes for 828 entries):
   ```
   cd knowledge_base
   python load_kb.py
   ```
6. **Publish** the workflow in n8n, then double-click `website/start_website.bat`
   and open http://localhost:10000.

To update an answer, edit `knowledge_base.csv` and run `python load_kb.py` again. No retraining is needed.

## Security notes

- No API keys are stored in this repository. Credentials live in n8n's encrypted store.
- Docker ports are bound to `127.0.0.1`; only the chat webhook is shared through Tailscale Funnel.
- For a production deployment, lock the chat endpoint to the client's domain (CORS) and add rate limiting.

## Team

| Member | ID | Role |
|---|---|---|
| Emon Dey | 59456 | Project lead, client liaison |
| Taukir Ahmed | 62063 | n8n RAG build, Qdrant, Docker, website |
| Md Ahsan Ullah | 63006 | Privacy and compliance |
| SK MD Samiul Islam Saimon | 62270 | Crisis safety |
| Abhishek Dangi | 57303 | Hosting and handover |

> In an emergency, call **000**. Jewish House 24/7 Crisis Line: **1300 544 357**.
