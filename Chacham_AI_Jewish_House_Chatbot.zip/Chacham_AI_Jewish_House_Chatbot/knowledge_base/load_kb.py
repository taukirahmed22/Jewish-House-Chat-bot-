"""
Load the Jewish House knowledge base into Qdrant (collection jh_qa).

Needs only Python 3 (no extra packages), Ollama running with nomic-embed-text,
and Qdrant running on localhost:6333.

Usage (from this folder):
    python load_kb.py                  # loads knowledge_base.csv
    python load_kb.py other_file.csv   # loads another CSV

CSV columns: id, title, tag, content, source
  - tag says what kind of source it is, e.g. "Approved Q&A (current)",
    "Current service information", "Impact report 2025", "Historical research publication (2018)".
  - Older CSVs with columns id, question, answer, source_url also work.
Re-running is safe: the collection is deleted and rebuilt each time.
"""
import csv, json, sys, time, urllib.request

OLLAMA = "http://localhost:11434"
QDRANT = "http://localhost:6333"
COLLECTION = "jh_qa"
MODEL = "nomic-embed-text"
DIM = 768
BATCH = 64

def call(method, url, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read() or b"{}")

def embed(text):
    vec = call("POST", f"{OLLAMA}/api/embeddings", {"model": MODEL, "prompt": text})["embedding"]
    if len(vec) != DIM:
        sys.exit(f"Expected {DIM} dimensions, got {len(vec)}. Is the model {MODEL}?")
    return vec

def to_record(r, i):
    if r.get("content"):
        tag, title = r.get("tag", "").strip(), r.get("title", "").strip()
        content = f"[{tag}] {title}\n{r['content'].strip()}" if tag else r["content"].strip()
        meta = {"id": r.get("id", str(i)), "title": title, "tag": tag, "source_url": r.get("source", "").strip()}
    else:  # old question/answer format
        content = f"Q: {r['question'].strip()}\nA: {r['answer'].strip()}"
        meta = {"id": r.get("id", str(i)), "title": r["question"].strip(),
                "tag": "Approved Q&A (current)", "source_url": r.get("source_url", "").strip()}
    return content, meta

def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "knowledge_base.csv"
    with open(path, newline="", encoding="utf-8") as f:
        rows = [r for r in csv.DictReader(f) if (r.get("content") or r.get("answer") or "").strip()]
    print(f"Read {len(rows)} entries from {path}")

    try:
        call("DELETE", f"{QDRANT}/collections/{COLLECTION}")
    except Exception:
        pass
    call("PUT", f"{QDRANT}/collections/{COLLECTION}", {"vectors": {"size": DIM, "distance": "Cosine"}})
    print(f"Created collection {COLLECTION} ({DIM}-d, cosine)")

    start, batch = time.time(), []
    for i, r in enumerate(rows, start=1):
        content, meta = to_record(r, i)
        # 'content' and 'metadata' are the payload keys n8n's Qdrant node reads
        batch.append({"id": i, "vector": embed(content), "payload": {"content": content, "metadata": meta}})
        if len(batch) == BATCH or i == len(rows):
            call("PUT", f"{QDRANT}/collections/{COLLECTION}/points?wait=true", {"points": batch})
            batch = []
            print(f"  loaded {i}/{len(rows)}  ({time.time() - start:.0f}s)")

    count = call("POST", f"{QDRANT}/collections/{COLLECTION}/points/count", {"exact": True})
    print(f"Done. {COLLECTION} now holds {count['result']['count']} points.")

if __name__ == "__main__":
    main()
