import os, re, csv, subprocess, sys
SRC = sys.argv[1]
OUT = sys.argv[2]
# category, label, url for each folder
CAT = {
 "Services": ("Current service information", "https://jewishhouse.org.au/services/"),
 "Contact": ("Current contact details", "https://jewishhouse.org.au/contact/"),
 "About": ("About Jewish House", "https://jewishhouse.org.au/about-us/"),
 "Support Us": ("Ways to support Jewish House", "https://jewishhouse.org.au/partner/"),
 "Our Impact": ("Our impact", "https://jewishhouse.org.au/our-impact/"),
 "Impact Reports": ("Impact report", "https://jewishhouse.org.au/our-impact/"),
 "Research publications": ("Historical research publication", "https://jewishhouse.org.au/our-impact/"),
}
TITLES = {"ewish House Crisis": "Jewish House Crisis Accommodation Program, Preliminary Results (UTS, 2017)",
          "DEMOGRAPHIC AND CLINICAL": "Demographic and Clinical Profile of Homeless Victims of Domestic Violence (Jewish House DV Program)",
          "Sefa's Report": "Theory of Change and Outcomes Framework for Jewish House (Sefa, 2022)",
          "JEWISH HOUSE STATEMENT OF COMMITMENT TO CHILD SAFE": "Jewish House Statement of Commitment to Child Safety",
          "MODEL OF CARE VALUES PRINCIPLES": "Jewish House Model of Care: Values and Principles",
          "Jewish House Project Plan": "Jewish House Project Plan (Project 2500, HomeBase program)"}

def clean(t):
    t = t.replace("\f", "\n")
    lines = [l.strip() for l in t.split("\n")]
    lines = [l for l in lines if not re.match(r"\d{1,2}/\d{1,2}/\d{2,4}, \d{1,2}:\d{2} ?(AM|PM)", l)]
    lines = [l for l in lines if not re.fullmatch(r"https?://\S+( \d+/\d+)?", l)]
    lines = [l for l in lines if l and not re.fullmatch(r"(page\s*)?\d{1,3}(\s*of\s*\d+)?", l, re.I)]
    t = "\n".join(lines)
    t = re.sub(r"[ \t]+", " ", t)
    # join wrapped lines: newline followed by lowercase continues a sentence
    t = re.sub(r"\n(?=[a-z(,;])", " ", t)
    return t

def chunk(text, size=900, overlap=150):
    paras = [p.strip() for p in re.split(r"\n+", text) if p.strip()]
    chunks, cur = [], ""
    for p in paras:
        if len(cur) + len(p) + 1 <= size:
            cur = (cur + " " + p).strip()
        else:
            if cur: chunks.append(cur)
            if len(p) > size:
                # split long paragraph by sentences
                sents = re.split(r"(?<=[.!?])\s+", p)
                cur = ""
                for s in sents:
                    if len(cur) + len(s) + 1 <= size: cur = (cur + " " + s).strip()
                    else:
                        if cur: chunks.append(cur)
                        cur = s[:size]
            else:
                tail = chunks[-1][-overlap:] if chunks else ""
                tail = tail[tail.find(" ")+1:] if " " in tail else tail
                cur = (tail + " " + p).strip() if tail else p
    if cur: chunks.append(cur)
    return [c for c in chunks if len(c) > 80]

# find boilerplate lines repeated across the website-page PDFs
from collections import Counter
WEB = ["Services","Contact","About","Support Us","Our Impact"]
cnt = Counter()
for folder in WEB:
    d=os.path.join(SRC,folder)
    for fn in os.listdir(d):
        if fn.lower().endswith(".pdf"):
            raw=subprocess.run(["pdftotext",os.path.join(d,fn),"-"],capture_output=True,text=True).stdout
            cnt.update(set(l.strip() for l in raw.replace("\f","\n").split("\n") if l.strip()))
BOILER = {l for l,c in cnt.items() if c >= 3}
rows, report = [], []
for folder, (label, url) in CAT.items():
    d = os.path.join(SRC, folder)
    if not os.path.isdir(d): continue
    for fn in sorted(os.listdir(d)):
        if not fn.lower().endswith(".pdf"): continue
        stem = fn[:-4]
        raw = subprocess.run(["pdftotext", os.path.join(d, fn), "-"], capture_output=True, text=True).stdout
        if folder in WEB:
            raw = "\n".join(l for l in raw.replace("\f","\n").split("\n") if l.strip() not in BOILER)
        text = clean(raw)
        if stem == "ewish House Crisis":
            # remove client interview transcripts (section 3 "Success stories")
            m = re.search(r"\n3\.?\s*Success stories", text[2000:], re.I)
            if m:
                cut = 2000 + m.start()
                text = text[:cut]
        title = TITLES.get(stem, stem)
        year = re.search(r"(20\d\d)", stem)
        if folder == "Impact Reports": tag = f"Impact report {stem}"
        elif folder == "Research publications": tag = f"{label}" + (f" ({year.group(1)})" if year else "")
        else: tag = label
        cs = chunk(text)
        report.append((folder, title, len(cs)))
        for i, c in enumerate(cs, 1):
            rows.append({"title": f"{title}", "tag": tag, "content": c, "source": url, "file": f"{folder}/{fn}", "part": i})
with open(OUT, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["id","title","tag","content","source","file","part"])
    w.writeheader()
    for i, r in enumerate(rows, 1):
        w.writerow({"id": i, **r})
for r in report: print(f"{r[2]:4d} chunks | {r[0]} | {r[1]}")
print("TOTAL", len(rows))
